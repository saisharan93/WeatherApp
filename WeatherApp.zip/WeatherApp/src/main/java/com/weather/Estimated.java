
package com.weather;


public class Estimated {


}
