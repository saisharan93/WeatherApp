package com.weather;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/weather")
public class WeatherController {
	
	@RequestMapping(method = RequestMethod.GET)
	public String getMessage() {
		return "index";
	}
	
	@RequestMapping(method = RequestMethod.POST, value="report")
	public ResponseData getWeatherReport(@RequestBody RequestData request) {
		String city = request.getCity();
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://api.wunderground.com/api/0febb2c6dfdd1e46/conditions/q/";
		url = url + city + ".json";
		ResponseData responseData = restTemplate.getForObject(url, ResponseData.class);
		
		return responseData;
	}

}
